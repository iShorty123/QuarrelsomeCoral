﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpitterFish : BaseEnemy
{
    public override void Attack()
    {
        throw new System.NotImplementedException();
    }

    public override void Move()
    {
        throw new System.NotImplementedException();
    }

    public override void HitSubmarine(ContactPoint2D _impactSpot)
    {
        throw new System.NotImplementedException();
    }

    public override void HitShield(ContactPoint2D _impactSpot)
    {

    }

    public override void TakeDamage(int _damage)
    {
        throw new System.NotImplementedException();
    }




    // Start is called before the first frame update
    new void Start()
    {
          
    }

    // Update is called once per frame
    new void Update()
    {
        
    }
}
