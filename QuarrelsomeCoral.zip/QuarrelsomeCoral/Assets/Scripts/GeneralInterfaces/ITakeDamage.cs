﻿
public interface ITakeDamage
{

    void TakeDamage(int _damage);



}
